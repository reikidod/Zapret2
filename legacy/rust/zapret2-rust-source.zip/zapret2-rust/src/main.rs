#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use anyhow::{anyhow, Context, Result};
use eframe::egui::{self, Align, Color32, FontId, Layout, RichText, ScrollArea, TextEdit, Vec2};
use serde::{Deserialize, Serialize};
use std::{
    fs,
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::mpsc::{self, Receiver, Sender},
    thread,
    time::{Duration, Instant},
};

const APP_NAME: &str = "Zapret2ControlCenter";
const BUILTIN_VERSION: u32 = 2;
const FLOWSEAL_RAW: &str = "https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/main/lists/";

#[derive(Clone, Serialize, Deserialize)]
struct Profile { name: String, args: String, note: String }
#[derive(Default, Serialize, Deserialize)]
struct Config { base_dir: String, lua_override: String, active: String, builtin_version: u32, profiles: Vec<Profile> }
#[derive(Default, Clone)]
struct Components { winws2: Option<PathBuf>, lua: Option<PathBuf>, blockcheck: Option<PathBuf> }

fn app_dir() -> PathBuf { dirs::config_dir().unwrap_or_else(std::env::temp_dir).join(APP_NAME) }
fn config_path() -> PathBuf { app_dir().join("config.json") }
fn read_config() -> Config {
    let mut c = fs::read(config_path()).ok().and_then(|b| serde_json::from_slice::<Config>(&b).ok()).unwrap_or_default();
    if c.profiles.is_empty() { c.profiles = builtins(); }
    else if c.builtin_version < BUILTIN_VERSION {
        for p in builtins() { if !c.profiles.iter().any(|x| x.name == p.name) { c.profiles.insert(0, p); } }
    }
    c.builtin_version = BUILTIN_VERSION;
    if c.active.is_empty() { c.active = c.profiles.first().map(|p| p.name.clone()).unwrap_or_default(); }
    c
}
fn save_config(c: &Config) -> Result<()> {
    fs::create_dir_all(app_dir())?;
    let tmp = config_path().with_extension("tmp");
    fs::write(&tmp, serde_json::to_vec_pretty(c)?)?;
    fs::rename(tmp, config_path()).context("Не удалось сохранить настройки")
}
fn builtins() -> Vec<Profile> {
    let common = "--wf-tcp-out=80,443\n--wf-udp-out=443\n--lua-init=@\"{LUA}\\zapret-lib.lua\" --lua-init=@\"{LUA}\\zapret-antidpi.lua\"\n--lua-init=\"fake_default_tls = tls_mod(fake_default_tls,'rnd,rndsni')\"\n";
    let http = "--filter-tcp=80 --filter-l7=http\n{LISTS}\n--out-range=-d10\n--payload=http_req\n--lua-desync=fake:blob=fake_default_http:ip_autottl=-2,3-20:ip6_autottl=-2,3-20:tcp_md5\n--lua-desync=fakedsplit:ip_autottl=-2,3-20:ip6_autottl=-2,3-20:tcp_md5\n--new\n";
    let quic = "--filter-udp=443 --filter-l7=quic\n{LISTS}\n--payload=quic_initial\n--lua-desync=fake:blob=fake_default_quic:repeats=11\n";
    let list_args = "--hostlist=\"{LISTS}\\list-general.txt\" --hostlist=\"{LISTS}\\list-google.txt\" --hostlist=\"{LISTS}\\list-general-user.txt\"\n--hostlist-exclude=\"{LISTS}\\list-exclude.txt\" --hostlist-exclude=\"{LISTS}\\list-exclude-user.txt\"";
    let tls_desync = [
        ("01 Официальный пример", "Копия логики preset2_example: fake + multidisorder.", "--lua-desync=fake:blob=fake_default_tls:tcp_md5:tcp_seq=-10000:repeats=6\n--lua-desync=multidisorder:pos=midsld"),
        ("02 Стиль YouTube", "Fake с SNI www.google.com + multidisorder.", "--lua-desync=fake:blob=fake_default_tls:tcp_md5:repeats=11:tls_mod=rnd,dupsid,sni=www.google.com\n--lua-desync=multidisorder:pos=1,midsld"),
        ("03 Фейк без ACK", "Фулинг через сброс ACK вместо md5.", "--lua-desync=fake:blob=fake_default_tls:tcp_flags_unset=ack:tls_mod=rnd,rndsni,dupsid,padencap:repeats=6\n--lua-desync=multidisorder:pos=midsld"),
        ("04 Битый ACK (по спискам)", "Fake + fakedsplit с битым ACK и авто-TTL.", "--lua-desync=fake:blob=fake_default_tls:tcp_ack=-66000:tcp_ts_up:ip_autottl=-2,3-20:ip6_autottl=-2,3-20:tls_mod=rnd,dupsid,sni=www.google.com:repeats=6\n--lua-desync=fakedsplit:pos=midsld:tcp_ack=-66000:tcp_ts_up:ip_autottl=-2,3-20:ip6_autottl=-2,3-20"),
        ("05 Multisplit seqovl", "Без фейков: разрез ClientHello с перекрытием seqovl.", "--lua-desync=multisplit:pos=1:seqovl=5:seqovl_pattern=0x1603030000"),
        ("06 Fake + hostfakesplit", "Экспериментальный fake + hostfakesplit.", "--lua-desync=fake:blob=fake_default_tls:tcp_md5:repeats=6:tls_mod=rnd,dupsid,sni=www.google.com\n--lua-desync=hostfakesplit:host=www.google.com:ip_autottl=-2,3-20:ip6_autottl=-2,3-20:tcp_md5"),
        ("07 Фулинг по timestamp", "Требуются включённые TCP timestamps.", "--lua-desync=fake:blob=fake_default_tls:tcp_ts=-1000:tls_mod=rnd,sni=www.google.com:repeats=6\n--lua-desync=multidisorder:pos=midsld"),
        ("08 Только disorder", "Лёгкий вариант без fake.", "--lua-desync=multidisorder:pos=midsld"),
    ];
    tls_desync.iter().map(|(name,note,ds)| {
        let tls = format!("--filter-tcp=443 --filter-l7=tls\n{{LISTS}}\n--out-range=-d10\n--payload=tls_client_hello\n{}\n--new\n", ds);
        let args = format!("{}{}{}{}", common, http.replace("{LISTS}", list_args), tls.replace("{LISTS}", list_args), quic.replace("{LISTS}", list_args));
        Profile { name: (*name).to_string(), args, note: format!("ТОЛЬКО ПО СПИСКАМ. {}", note) }
    }).collect()
}
fn find_components(root: &Path) -> Components {
    let mut c = Components::default();
    let mut stack = vec![(root.to_path_buf(), 0usize)];
    while let Some((dir, depth)) = stack.pop() {
        if depth > 7 { continue; }
        let Ok(rd) = fs::read_dir(&dir) else { continue };
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                let n = p.file_name().unwrap_or_default().to_string_lossy().to_lowercase();
                if ![".git", "cygwin", "node_modules", "windows", "appdata"].contains(&n.as_str()) { stack.push((p, depth+1)); }
            } else if let Some(n) = p.file_name().map(|x| x.to_string_lossy().to_lowercase()) {
                if n == "winws2.exe" && c.winws2.is_none() { c.winws2 = Some(p.clone()); }
                if n == "zapret-lib.lua" && c.lua.is_none() { c.lua = p.parent().map(Path::to_path_buf); }
                if n == "blockcheck2.cmd" && c.blockcheck.is_none() { c.blockcheck = Some(p.clone()); }
            }
        }
    }
    if let Some(exe) = &c.winws2 {
        for a in exe.ancestors().take(5) {
            if c.lua.is_none() { for x in [a.join("lua"), a.join("zapret-winws/lua")] { if x.join("zapret-lib.lua").is_file() { c.lua=Some(x); break; } } }
            if c.blockcheck.is_none() { for x in [a.join("blockcheck2.cmd"), a.join("blockcheck/blockcheck2.cmd")] { if x.is_file() { c.blockcheck=Some(x); break; } } }
        }
    }
    c
}
fn default_search_roots() -> Vec<PathBuf> {
    let mut v=vec![std::env::current_dir().unwrap_or_default()];
    if let Some(d)=dirs::download_dir(){v.push(d)} if let Some(d)=dirs::desktop_dir(){v.push(d)} if let Some(d)=dirs::document_dir(){v.push(d)}
    if let Some(h)=dirs::home_dir(){v.push(h)}
    #[cfg(windows)] for ch in b'C'..=b'Z' { let p=PathBuf::from(format!("{}:\\",ch as char)); if p.exists(){v.push(p)} }
    v
}
fn discover() -> Option<PathBuf> {
    for root in default_search_roots() {
        let mut todo=vec![(root,0)];
        while let Some((d,n))=todo.pop(){ if n>4 {continue} let Ok(rd)=fs::read_dir(&d) else {continue}; for e in rd.flatten(){let p=e.path(); if p.file_name().map(|x|x.to_string_lossy().eq_ignore_ascii_case("winws2.exe")).unwrap_or(false){return p.parent().map(Path::to_path_buf)} if p.is_dir(){let name=p.file_name().unwrap_or_default().to_string_lossy().to_lowercase(); if !["windows","appdata",".git","cygwin","node_modules"].contains(&name.as_str()){todo.push((p,n+1));}}}}
    } None
}
fn is_admin() -> bool { #[cfg(windows)] { use windows::Win32::UI::Shell::IsUserAnAdmin; unsafe { IsUserAnAdmin().as_bool() } } #[cfg(not(windows))] { true } }
fn elevate() { #[cfg(windows)] { use windows::core::PCWSTR; use windows::Win32::UI::Shell::ShellExecuteW; use windows::Win32::UI::WindowsAndMessaging::SW_SHOWNORMAL; let exe=std::env::current_exe().unwrap_or_default(); let op:Vec<u16>="runas\0".encode_utf16().collect(); let path:Vec<u16>=exe.to_string_lossy().encode_utf16().chain([0]).collect(); unsafe { let _=ShellExecuteW(None,PCWSTR(op.as_ptr()),PCWSTR(path.as_ptr()),PCWSTR::null(),PCWSTR::null(),SW_SHOWNORMAL); } } }
fn running_dpi() -> bool { #[cfg(windows)] { Command::new("tasklist").args(["/FI","IMAGENAME eq winws2.exe","/NH"]).output().map(|o|String::from_utf8_lossy(&o.stdout).to_lowercase().contains("winws2.exe")).unwrap_or(false) } #[cfg(not(windows))] { false } }
fn resolve_args(src: &str, c: &Components, lists: &Path, debug: bool) -> Result<Vec<String>> {
    let bin=c.winws2.as_ref().and_then(|p|p.parent()).ok_or_else(||anyhow!("Не найден winws2.exe"))?;
    let lua=c.lua.as_ref().ok_or_else(||anyhow!("Не найдена папка Lua с zapret-lib.lua"))?;
    let s=src.replace("{BIN}",&bin.to_string_lossy()).replace("{LUA}",&lua.to_string_lossy()).replace("{LISTS}",&lists.to_string_lossy());
    let mut out=Vec::new();
    for line in s.lines(){let t=line.trim(); if t.is_empty()||t.starts_with('#')||t=="--new" {if t=="--new"{out.push(t.into());} continue;} out.extend(split_args(t)?);}
    if debug && !out.iter().any(|x| x == "--debug") { out.insert(0, "--debug".into()); }
    Ok(out)
}
fn split_args(s:&str)->Result<Vec<String>> { let mut out=Vec::new(); let mut cur=String::new(); let mut quote=None; let mut esc=false; for ch in s.chars(){ if esc {cur.push(ch);esc=false;continue} if ch=='\\' && quote.is_some(){cur.push(ch);esc=false;continue} if let Some(q)=quote {if ch==q{quote=None}else{cur.push(ch)}} else if ch=='"'||ch=='\''{quote=Some(ch)} else if ch.is_whitespace(){if !cur.is_empty(){out.push(std::mem::take(&mut cur));}} else {cur.push(ch)} } if quote.is_some(){return Err(anyhow!("Незакрытая кавычка в параметрах"));} if !cur.is_empty(){out.push(cur)} Ok(out) }

fn ensure_list_files(dir:&Path){
    let _=fs::create_dir_all(dir);
    let seed=[
      ("list-general.txt", "# Discord и сопутствующие домены\ndiscord.com\ndiscord.gg\ndiscordapp.com\ndiscordapp.net\ndiscord.media\ndiscordcdn.com\ndiscordstatus.com\ndiscord.new\ndiscord.gift\n"),
      ("list-google.txt", "# YouTube и связанные домены Google\nyoutube.com\nyoutu.be\nyoutube-nocookie.com\nyoutubei.googleapis.com\ngooglevideo.com\nytimg.com\nyt3.ggpht.com\n"),
      ("list-general-user.txt", "# Ваши домены, по одному на строку.\n"),
      ("list-exclude.txt", "# Домены-исключения\n"),
      ("list-exclude-user.txt", "# Ваши исключения, по одному на строку.\n")
    ];
    for (name,body) in seed {let p=dir.join(name);if !p.exists(){let _=fs::write(p,body);}}
}

fn update_lists(dir:&Path)->Vec<String>{ let mut report=Vec::new(); let _=fs::create_dir_all(dir); for name in ["list-general.txt","list-google.txt","list-exclude.txt"] { let url=format!("{}{}",FLOWSEAL_RAW,name); let output=Command::new("powershell").args(["-NoProfile","-Command",&format!("try {{ (Invoke-WebRequest -UseBasicParsing -TimeoutSec 20 '{}').Content }} catch {{ exit 1 }}",url)]).output(); match output {Ok(o) if o.status.success()=>{let text=String::from_utf8_lossy(&o.stdout).to_string();let lines:Vec<_>=text.lines().filter(|x|!x.trim().is_empty()&&!x.trim_start().starts_with('#')).collect();if lines.len()>=3&&lines.iter().all(|x|x.chars().all(|c|c.is_ascii_alphanumeric()||".-_^".contains(c))){let p=dir.join(name);if p.exists(){let _=fs::copy(&p,p.with_extension("txt.bak"));} match fs::write(&p,text){Ok(_)=>report.push(format!("{}: обновлён",name)),Err(e)=>report.push(format!("{}: {}",name,e))}}else{report.push(format!("{}: ответ не прошёл проверку",name))}},_=>report.push(format!("{}: ошибка загрузки",name))} } report }

struct App {
    cfg: Config, comps: Components, selected: usize, page: usize, base_input: String, args_edit: String, name_edit: String, note_edit: String,
    lists_dir: PathBuf, child: Option<Child>, logs: Vec<String>, tx: Sender<String>, rx: Receiver<String>, status: String, debug: bool, last_poll: Instant,
}
impl App {
    fn new()->Self { let cfg=read_config(); let (tx,rx)=mpsc::channel(); let mut a=Self{base_input:cfg.base_dir.clone(),cfg,comps:Components::default(),selected:0,page:0,args_edit:String::new(),name_edit:String::new(),note_edit:String::new(),lists_dir:app_dir().join("lists"),child:None,logs:vec![],tx,rx,status:"Поиск компонентов…".into(),debug:false,last_poll:Instant::now()}; let _=fs::create_dir_all(&a.lists_dir); ensure_list_files(&a.lists_dir); a.load_selected(); a.refresh_components(); if a.comps.winws2.is_none(){if let Some(p)=discover(){a.base_input=p.display().to_string();a.refresh_components();}} a }
    fn log(&mut self,s:impl Into<String>){self.logs.push(s.into());if self.logs.len()>1800{self.logs.drain(0..300);}}
    fn load_selected(&mut self){if self.cfg.profiles.is_empty(){return} self.selected=self.cfg.profiles.iter().position(|p|p.name==self.cfg.active).unwrap_or(0).min(self.cfg.profiles.len()-1);let p=&self.cfg.profiles[self.selected];self.name_edit=p.name.clone();self.note_edit=p.note.clone();self.args_edit=p.args.clone();}
    fn commit(&mut self){if let Some(p)=self.cfg.profiles.get_mut(self.selected){p.name=self.name_edit.clone();p.note=self.note_edit.clone();p.args=self.args_edit.clone();self.cfg.active=p.name.clone();}let _=save_config(&self.cfg);}
    fn refresh_components(&mut self){let p=PathBuf::from(self.base_input.trim());if p.is_dir(){self.comps=find_components(&p);self.cfg.base_dir=self.base_input.clone();let _=save_config(&self.cfg);} self.status=if self.comps.winws2.is_some(){"Zapret2 обнаружен".into()}else{"winws2.exe не найден".into()}; if let Some(p)=&self.comps.winws2{self.log(format!("winws2: {}",p.display()));} if let Some(p)=&self.comps.blockcheck{self.log(format!("blockcheck2: {}",p.display()));} }
    fn start(&mut self){self.commit();if !is_admin(){self.log("Требуются права администратора. Перезапустите приложение от имени администратора.");elevate();return} if running_dpi(){self.log("Обнаружен уже работающий winws2.exe. Остановите предыдущий обходчик перед запуском.");return} let Some(exe)=self.comps.winws2.clone() else{self.log("Не найден winws2.exe");return};let args=match resolve_args(&self.args_edit,&self.comps,&self.lists_dir,self.debug){Ok(v)=>v,Err(e)=>{self.log(e.to_string());return}};match Command::new(&exe).args(args).current_dir(exe.parent().unwrap_or(Path::new("."))).stdout(Stdio::piped()).stderr(Stdio::piped()).spawn(){Ok(mut child)=>{if let Some(out)=child.stdout.take(){let tx=self.tx.clone();thread::spawn(move||{use std::io::{BufRead,BufReader};for l in BufReader::new(out).lines().flatten(){let _=tx.send(l);}});}if let Some(err)=child.stderr.take(){let tx=self.tx.clone();thread::spawn(move||{use std::io::{BufRead,BufReader};for l in BufReader::new(err).lines().flatten(){let _=tx.send(l);}});}self.child=Some(child);self.status="Работает".into();self.log("Запущен выбранный профиль.");},Err(e)=>self.log(format!("Ошибка запуска: {}",e))}}
    fn stop(&mut self){if let Some(mut c)=self.child.take(){match c.kill(){Ok(_)=>{let _=c.wait();self.status="Остановлен".into();self.log("Процесс остановлен.");},Err(e)=>self.log(format!("Не удалось остановить процесс: {}",e))}}}
    fn blockcheck(&mut self){if self.child.is_some(){self.log("Сначала остановите запущенный winws2.");return}if running_dpi(){self.log("Другой winws2.exe ещё работает. Остановите его перед blockcheck2.");return}let Some(p)=self.comps.blockcheck.clone() else{self.log("Не найден blockcheck2.cmd. Проверьте корневую папку zapret-win-bundle.");return};let result=Command::new("cmd.exe").args(["/d","/k"]).arg(format!("call \"{}\"",p.display())).current_dir(p.parent().unwrap_or(Path::new("."))).spawn();match result{Ok(_)=>self.log("blockcheck2.cmd открыт в отдельной консоли."),Err(e)=>self.log(format!("Ошибка запуска blockcheck2: {}",e))}}
    fn import_cmd(&mut self){if let Some(p)=rfd::FileDialog::new().add_filter("CMD/BAT",&["cmd","bat"]).pick_file(){match fs::read_to_string(&p){Ok(s)=>{let args=extract_cmd(&s);if args.is_empty(){self.log("Не удалось извлечь аргументы winws2 из выбранного файла.");}else{self.cfg.profiles.push(Profile{name:p.file_stem().unwrap_or_default().to_string_lossy().into(),note:format!("Импортировано из {}",p.display()),args});self.selected=self.cfg.profiles.len()-1;self.load_selected();self.commit();self.log(format!("Импортировано: {}",p.display()));}},Err(e)=>self.log(e.to_string())}}}
}
fn extract_cmd(s:&str)->String{let mut v=Vec::new();for l in s.lines(){let t=l.trim().trim_end_matches('^').trim();if t.starts_with("--")||t.starts_with("\"--"){v.push(t.to_string());}}v.join("\n")}
impl eframe::App for App {
 fn update(&mut self,ctx:&egui::Context,_:&mut eframe::Frame){while let Ok(l)=self.rx.try_recv(){self.log(l)}if self.last_poll.elapsed()>Duration::from_millis(250){if let Some(c)=self.child.as_mut(){if let Ok(Some(code))=c.try_wait(){self.child=None;self.status=format!("Завершился (код {})",code);self.log(self.status.clone());}}self.last_poll=Instant::now();}
  let bg=Color32::from_rgb(14,19,29);let panel=Color32::from_rgb(23,31,45);let panel2=Color32::from_rgb(30,41,59);let accent=Color32::from_rgb(75,143,255);let text=Color32::from_rgb(232,239,249);let muted=Color32::from_rgb(151,166,188);
  egui::CentralPanel::default().frame(egui::Frame::default().fill(bg).inner_margin(18.0)).show(ctx,|ui|{
   ui.horizontal(|ui|{ui.vertical(|ui|{ui.label(RichText::new("ZAPRET2").size(23.0).strong().color(text));ui.label(RichText::new("CONTROL CENTER  •  WINDOWS 11").size(10.0).color(muted));});ui.with_layout(Layout::right_to_left(Align::Center),|ui|{ui.label(RichText::new(&self.status).color(if self.child.is_some(){Color32::LIGHT_GREEN}else{muted}).strong());ui.add_space(12.0);if ui.button("⚙  Настройки").clicked(){self.page=3;}});});ui.add_space(14.0);
   ui.horizontal(|ui|{for (i,label) in ["Обзор","Стратегии","Списки","Настройки"].iter().enumerate(){let selected=self.page==i;if ui.add_sized([112.0,34.0],egui::Button::new(RichText::new(*label).color(if selected{Color32::WHITE}else{muted})).fill(if selected{accent}else{panel})).clicked(){self.page=i;}}});ui.add_space(14.0);
   match self.page {
    0=>{ui.columns(2,|cols|{egui::Frame::none().fill(panel).rounding(12.0).inner_margin(14.0).show(&mut cols[0],|ui|{ui.label(RichText::new("Подключение Zapret2").size(17.0).strong().color(text));ui.add_space(8.0);ui.label(RichText::new("Папка с winws2.exe / zapret-win-bundle").color(muted));ui.horizontal(|ui|{ui.add_sized([ui.available_width()-88.0,30.0],TextEdit::singleline(&mut self.base_input));if ui.button("Обзор…").clicked(){if let Some(p)=rfd::FileDialog::new().pick_folder(){self.base_input=p.display().to_string();self.refresh_components();}}});ui.horizontal(|ui|{if ui.button("Проверить папку").clicked(){self.refresh_components();}if ui.button("Найти автоматически").clicked(){if let Some(p)=discover(){self.base_input=p.display().to_string();self.refresh_components();}else{self.log("winws2.exe не найден в стандартных папках.");}}});ui.separator();for (n,p) in [("winws2.exe",self.comps.winws2.as_ref()),("Lua",self.comps.lua.as_ref()),("blockcheck2",self.comps.blockcheck.as_ref())]{ui.horizontal(|ui|{ui.label(RichText::new(if p.is_some(){"●"}else{"○"}).color(if p.is_some(){Color32::LIGHT_GREEN}else{Color32::LIGHT_RED}));ui.label(n);ui.with_layout(Layout::right_to_left(Align::Center),|ui|{ui.label(RichText::new(p.map(|x|x.display().to_string()).unwrap_or_else(||"Не найдено".into())).size(10.0).color(muted));});});}});
    egui::Frame::none().fill(panel).rounding(12.0).inner_margin(14.0).show(&mut cols[1],|ui|{ui.label(RichText::new("Быстрые действия").size(17.0).strong().color(text));ui.add_space(8.0);let running=self.child.is_some();if ui.add_sized([ui.available_width(),42.0],egui::Button::new(RichText::new(if running{"Остановить winws2"}else{"Запустить выбранную стратегию"}).strong()).fill(if running{Color32::from_rgb(170,65,75)}else{accent})).clicked(){if running{self.stop()}else{self.start()}}ui.add_space(8.0);if ui.add_sized([ui.available_width(),36.0],egui::Button::new("Подбор стратегии · blockcheck2").fill(panel2)).clicked(){self.blockcheck()}ui.add_space(8.0);ui.checkbox(&mut self.debug,"Включить --debug");ui.label(RichText::new("blockcheck2 запускается отдельно и требует остановленного обходчика.").size(11.0).color(muted));});});
    egui::Frame::none().fill(panel).rounding(12.0).inner_margin(12.0).show(ui,|ui|{ui.horizontal(|ui|{ui.label(RichText::new("Журнал событий").strong().color(text));ui.with_layout(Layout::right_to_left(Align::Center),|ui|{if ui.small_button("Очистить").clicked(){self.logs.clear();}})});ScrollArea::vertical().max_height(190.0).stick_to_bottom(true).show(ui,|ui|{for l in &self.logs{ui.label(RichText::new(l).monospace().size(11.0).color(muted));}});});},
    1=>{ui.columns(2,|cols|{egui::Frame::none().fill(panel).rounding(12.0).inner_margin(10.0).show(&mut cols[0],|ui|{ui.label(RichText::new("Встроенные и пользовательские профили").strong().color(text));ui.separator();ScrollArea::vertical().show(ui,|ui|{for i in 0..self.cfg.profiles.len(){let selected=i==self.selected;let name=self.cfg.profiles[i].name.clone();if ui.selectable_label(selected,RichText::new(name).color(if selected{text}else{muted})).clicked(){self.commit();self.selected=i;self.load_selected();}}});ui.separator();ui.horizontal(|ui|{if ui.button("＋ Новый").clicked(){self.commit();self.cfg.profiles.push(Profile{name:"Новый профиль".into(),note:String::new(),args:"--wf-tcp-out=80,443\n".into()});self.selected=self.cfg.profiles.len()-1;self.load_selected();}if ui.button("Копия").clicked(){self.commit();let p=self.cfg.profiles[self.selected].clone();self.cfg.profiles.push(Profile{name:format!("{} — копия",p.name),..p});self.selected=self.cfg.profiles.len()-1;self.load_selected();}if ui.button("Удалить").clicked()&&self.cfg.profiles.len()>1{self.cfg.profiles.remove(self.selected);self.selected=0;self.load_selected();}});});egui::Frame::none().fill(panel).rounding(12.0).inner_margin(12.0).show(&mut cols[1],|ui|{ui.label(RichText::new("Редактор стратегии").strong().color(text));ui.label("Название");ui.text_edit_singleline(&mut self.name_edit);ui.label("Описание");ui.add(TextEdit::multiline(&mut self.note_edit).desired_rows(2));ui.label("Аргументы winws2");ui.add(TextEdit::multiline(&mut self.args_edit).font(FontId::monospace(12.0)).desired_rows(18).desired_width(f32::INFINITY));ui.horizontal(|ui|{if ui.button("Сохранить").clicked(){self.commit();self.log("Профиль сохранён.");}if ui.button("Импорт .cmd/.bat").clicked(){self.import_cmd();}});});});},
    2=>{egui::Frame::none().fill(panel).rounding(12.0).inner_margin(14.0).show(ui,|ui|{ui.label(RichText::new("Списки доменов").size(18.0).strong().color(text));ui.label(RichText::new(format!("Папка: {}",self.lists_dir.display())).color(muted));ui.horizontal(|ui|{if ui.button("Открыть папку").clicked(){#[cfg(windows)]{let _=Command::new("explorer").arg(&self.lists_dir).spawn();}}if ui.button("Обновить общие списки Flowseal").clicked(){let d=self.lists_dir.clone();let tx=self.tx.clone();thread::spawn(move||for s in update_lists(&d){let _=tx.send(s);});self.log("Запущено обновление списков. Пользовательские *-user.txt не изменяются.");}});ui.separator();for n in ["list-general.txt","list-google.txt","list-general-user.txt","list-exclude.txt","list-exclude-user.txt"]{let p=self.lists_dir.join(n);if !p.exists()&&n.contains("user"){let _=fs::write(&p,"# Ваши записи, по одной на строку. Файл не перезаписывается.\n");}ui.horizontal(|ui|{ui.label(RichText::new(n).color(text));ui.with_layout(Layout::right_to_left(Align::Center),|ui|{if ui.small_button("Открыть").clicked(){#[cfg(windows)]{let _=Command::new("notepad").arg(&p).spawn();}}});});}});},
    _=>{egui::Frame::none().fill(panel).rounding(12.0).inner_margin(14.0).show(ui,|ui|{ui.label(RichText::new("Настройки приложения").size(18.0).strong().color(text));ui.label("Путь к папке Zapret2");ui.text_edit_singleline(&mut self.base_input);ui.horizontal(|ui|{if ui.button("Сохранить путь").clicked(){self.refresh_components();}if ui.button("Перезапустить от администратора").clicked(){elevate();}});ui.separator();ui.label("Конфигурация и пользовательские списки хранятся в %APPDATA%\\Zapret2ControlCenter.");ui.label("Сам winws2, WinDivert, Lua и файлы стратегий поставляются отдельно в составе Zapret bundle.");});}
   }
  });ctx.request_repaint_after(Duration::from_millis(120));
 }
}
fn main()->eframe::Result<()> { let mut native=eframe::NativeOptions::default();native.viewport=egui::ViewportBuilder::default().with_inner_size([1220.0,820.0]).with_min_inner_size([960.0,680.0]).with_title("Zapret2 Control Center");eframe::run_native("Zapret2 Control Center",native,Box::new(|_cc|Ok(Box::new(App::new())))) }
